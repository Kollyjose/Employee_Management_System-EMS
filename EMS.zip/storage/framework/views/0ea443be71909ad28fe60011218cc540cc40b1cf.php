<!DOCTYPE html>
<html>
<head>
  <title>EMS</title>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.2.1/jquery.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>
  <style>
     table th,tr,td{

        text-align: center;
     }

  </style>
</head>
<body>


<?php echo $__env->make('header', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

<div class="container">
  <h2>Vehicle Informations</h2>    

        <?php if(session('info')): ?>
           <div class="alert alert-success">
            <?php echo e(session('info')); ?>

           </div>
         <?php endif; ?>

         <?php if(session('delinfo')): ?>
           <div class="alert alert-danger">
            <?php echo e(session('delinfo')); ?>

           </div>
         <?php endif; ?>

  <table class="table table-bordered">
    <thead>
      <tr>
        
        <th>Vehicle Number</th>
        <th>Road Permit</th>
        <th>Fitness</th>
        <th>Tax Token</th>
        <th>Insurance</th>
        <th>Action</th>
      </tr>
    </thead>
    <tbody>
      <?php if(count($vehicles) > 0): ?>
        <?php $__currentLoopData = $vehicles; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $vehicle): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
           <tr>
            <td><?php echo e($vehicle->no_car); ?></td>
            <td><?php echo e($vehicle->rp_due); ?></td>
            <td><?php echo e($vehicle->fc_due); ?></td>
            <td><?php echo e($vehicle->tt_due); ?></td>
            <td><?php echo e($vehicle->ic_due); ?></td>
            <td>
              <a href='<?php echo e(url("/edit_vreg/{$vehicle->v_id}")); ?>' class="btn btn-success" >Update </a> |
            <a href='<?php echo e(url("/del_vreg/{$vehicle->v_id}")); ?>' class="btn btn-danger" >Delete </a></td>
           </tr>
           <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
         <?php endif; ?> 
    </tbody>
  </table>
  <?php echo e($vehicles->links()); ?>

 
</div>


<?php echo $__env->make('footer', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

</body>
</html>
