<!DOCTYPE html>
<html>
<head>
  <title>EMS</title>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.2.1/jquery.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>
  <style>
     table th,tr,td{
        text-align: center;
        }

     .empImg{

       float: right;   
       }
       #bdy{
       
       }
       #contact{
        margin-bottom: 1px;
       }

  </style>
</head>
<body id="bdy">

<?php echo $__env->make('header', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

<div class="container">
  <h2>Employee's info</h2>    

        <?php if(session('info')): ?>
           <div class="alert alert-success">
            <?php echo e(session('info')); ?>

           </div>
         <?php endif; ?>

        <?php if(session('delinfo')): ?>
           <div class="alert alert-danger">
            <?php echo e(session('delinfo')); ?>

           </div>
         <?php endif; ?>

         <!-- <form action="" method="post" enctype="multipart/form-data">
           <input type="text" name="emp_search" class="form-group" placeholder="Search by ID">
           <button type="submit" name="submit" class="btn btn-primary"><i class="glyphicon glyphicon-search"></i></button>

         </form> -->

    <form action="<?php echo e(url('/emp_search')); ?>" method="post" enctype="multipart/form-data">
          <?php echo e(csrf_field()); ?>

      <div class="input-group">
         <input type="text" size="4" style="width:200px;" class="form-control" placeholder="Search by ID" name="empSearchId">
                
        <button class="btn btn-primary" type="submit"><i class="glyphicon glyphicon-search"></i></button>
        </div>
    </form>
      <br>


       
  <table class="table table-bordered" width="">
    <thead>
      <tr>
        <th>Employee ID</th>
        <th>Employee Name</th>
        <th>Emp Photos</th>
        <th>Address</th>
        <th>phone</th>
        <th>Action</th>
      </tr>
    </thead>
    <tbody>
      <?php if(count($employers) > 0): ?>
        <?php $__currentLoopData = $employers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $employer): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
           <tr>
            <td><?php echo e($employer->emp_id); ?></td>
            <td><?php echo e($employer->emp_name); ?></td>
            <td><img src="<?php echo e($employer->emp_pic); ?>"  style="border-radius:50%;" 
              height="100px"  width="120px"/>
            <br>
             </td>
            <td><?php echo e($employer->emp_address); ?></td>
            <td><?php echo e($employer->emp_phn_number); ?></td>
            <td> <a href='<?php echo e(url("/details/{$employer->emp_id}")); ?>' class="btn btn-primary">Details </a> |
             <a href='<?php echo e(url("/edit/{$employer->emp_id}")); ?>' class="btn btn-success">Update </a> |
              <a href='<?php echo e(url("/delete/{$employer->emp_id}")); ?>' class="btn btn-danger" >Delete </a></td>
           </tr>
           <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
         <?php endif; ?>  
    </tbody>
  </table>
  
</div>

<?php echo $__env->make('footer', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
</body>

</html>
