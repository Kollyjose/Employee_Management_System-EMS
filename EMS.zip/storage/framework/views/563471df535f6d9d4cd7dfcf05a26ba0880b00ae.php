<div id="contact" class="container-fluid" style="background-color: orange; 
color: white; margin-bottom: 0px; margin-top: 150px;">
  <div class="row">
    <div class="col-md-4">
      <h3 class="text-left">Contact</h3>
        <p class="text-left"><em>Mahamudun Hassan</em></p>
      <p><span class="glyphicon glyphicon-map-maker"></span> Badda, Dhaka</p>
      <p> <span class="glyphicon glyphicon-phone"></span> Phone:+8801850969739</p>
      <p><span class="glyphicon glyphicon-envelope"></span> Email:mahamudun013@gmail.com</p>
   </div>

    <div class="col-md-4" style="margin-top: 0px auto;">

        <br>
       <a href="https://www.facebook.com" style="font-size: 20px;"> <span class="glyphicon  glyphicon-envelope "> Facebook</span></a><br>
       <a href="#" style="font-size: 20px;">  <span class="glyphicon  glyphicon-envelope "> Twitter</span></a><br>
       <a href="https://www.Linkedin.com" style="font-size: 20px;"> <span class="glyphicon  glyphicon-envelope "> Linkedin</span></a><br>
       <a href="#" style="font-size: 20px; "> <span class="glyphicon  glyphicon-envelope "> Skype</span></a><br>
        

       </div>
    
     <div class="col-md-4">
       <br>
       <div style="border: 1px solid red; height: 150px; width: 300px; margin: 0px auto;background-color: blue;text-align: center;">
        <img src="<?php echo e(asset('public/images/map.png')); ?>" height="150px" width="300px">
       </div><br>
       <p style="font-size: 20px;text-align: center;">2018 &copy <strong>Mahamudun Hassan</strong></p> 
      </div>
  </div>
</div>