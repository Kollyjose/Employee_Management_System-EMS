<?php echo $__env->make('header', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

<div class="container">
  <h2>Employee's info</h2>    

        <?php if(session('info')): ?>
           <div class="alert alert-success">
            <?php echo e(session('info')); ?>

           </div>
         <?php endif; ?>

        <?php if(session('delinfo')): ?>
           <div class="alert alert-danger">
            <?php echo e(session('delinfo')); ?>

           </div>
         <?php endif; ?>
             
         <?php if(session('v1')): ?>
         <div class="alert alert-info alert-dismissible">
            <p><?php echo e(session('v1')); ?> days to left for rp.</p>
             </div>
         <?php endif; ?> 
         <?php if(session('v2')): ?>
         <div class="alert alert-info alert-dismissible">
            <p><?php echo e(session('v2')); ?> days to left for ff.</p>
             </div>
         <?php endif; ?> 
         <?php if(session('v3')): ?>
         <div class="alert alert-info alert-dismissible">
           <p><?php echo e(session('v3')); ?> days  to left for tt.</p>
            </div>
         <?php endif; ?> 
         <?php if(session('v4')): ?>
         <div class="alert alert-info alert-dismissible">
            <p><?php echo e(session('v4')); ?> days  to left for ic.</p>
           </div>  
         <?php endif; ?>    



         <?php echo e($item); ?> 
     
       
  

</div>
</body>
</html>
