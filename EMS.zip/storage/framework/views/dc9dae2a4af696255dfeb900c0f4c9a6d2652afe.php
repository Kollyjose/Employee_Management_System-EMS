<!DOCTYPE html>
<html>
<head>
  <title>EMS</title>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.2.1/jquery.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>
  <style>
     table th,tr,td{

        text-align: center;
     }

  </style>
</head>
<body>


<?php echo $__env->make('header', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

<div class="container">
  <h2>Employer Payment Entrys</h2>    

        <?php if(session('info')): ?>
           <div class="alert alert-success">
            <?php echo e(session('info')); ?>

           </div>
         <?php endif; ?>

        <?php if(session('delinfo')): ?>
           <div class="alert alert-danger">
            <?php echo e(session('delinfo')); ?>

           </div>
         <?php endif; ?>


   <form action='<?php echo e(url("/search_pay_details")); ?>' method="post" 
       enctype="multipart/form-data">
          <?php echo e(csrf_field()); ?>

       <div class="input-group">
         <input type="text" size="4" style="width:200px;" class="form-control" 
         placeholder="Ex: 2018-05-02" name="search">
                
        <button class="btn btn-primary" type="submit"><i class="glyphicon glyphicon-search"></i></button>
        </div>
    </form>
    <br>

 
    <!-- <form action='<?php echo e(url("/search_pay_details")); ?>' method="post" 
    enctype="multipart/form-data">
      <input type="text" placeholder=":2018-05-02" name="search">
      <button type="submit" class="glyphicon glyphicon-search"></button>
    </form> -->
 

  <table class="table table-bordered">
    <thead>
      <tr>
         <th>SL</th>
        <th>Emp ID</th>
        <th>Car Number</th>
        <th>Amount</th>
        <th>Due</th>
        <th>Due Payment</th>
        <th>Total Due</th>
        <th>Date</th>
        <th>Action</th>
      </tr>
    </thead>
    <tbody>
      <?php if(count($payments) > 0): ?>
        <?php $__currentLoopData = $payments; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $payment): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
           <tr>
            <td><?php echo e($no++); ?></td>
            <td><?php echo e($payment->emp_id); ?></td>
            <td><?php echo e($payment->no_car); ?></td>
            <td><?php echo e($payment->amount); ?></td>
            <td><?php echo e($payment->remaining); ?></td>
            <td><?php echo e($payment->paying_owed_amount); ?></td>
            <td><?php echo e($payment->total_paying_owed_am); ?></td>
            <td><?php echo e($payment->date); ?></td>
            <td><a href='<?php echo e(url("/edit_pay/{$payment->pay_id}")); ?>' class="btn btn-success" >Update </a> |
            <a href='<?php echo e(url("/del/{$payment->pay_id}")); ?>' class="btn btn-danger" >Delete </a></td>
           </tr>
           <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
         <?php endif; ?> 
    </tbody>
  </table>
   <div class="alert alert-success">
         <b>Total Amount = <?php echo e($total_amount); ?></b>
  </div>
  <?php echo e($payments->links()); ?>

 
</div>


<?php echo $__env->make('footer', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

</body>
</html>
