<nav style="border-radius: 0px;" class="navbar navbar-inverse">
  <div class="container-fluid">
    <div class="navbar-header">
      <a class="navbar-brand" class="active" href="#">Employee Management System</a>
    </div>
    <ul class="nav navbar-nav">
         <li><a class="active" href="<?php echo e(url('/home')); ?>">Home</a></li>
         <li><a href="<?php echo e(url('/check')); ?>" ><span class="glyphicon glyphicon-envelope">
          </span> Notification </a></li>
         <li> <a href="<?php echo e(url('/pay_view')); ?>">Payment Details</a></li>
         <li><a href="<?php echo e(url('/vehicle_reg_view')); ?>"> Vehicle Info</a></li>
         <li><a href="<?php echo e(url('/create')); ?>">Employee Registration</a></li>
         <li><a href="<?php echo e(url('/payment')); ?>">Employee Payment Entry</a></li>
         <li><a href="<?php echo e(url('/car_form')); ?>">Vehicle Register</a></li>
         <li><a href="<?php echo e(url('/logout')); ?>"><span class="glyphicon glyphicon-log-out"></span> Log out</a></li>


    </ul>
  </div>
</nav>
