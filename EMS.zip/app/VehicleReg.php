<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class VehicleReg extends Model
{
    protected $table='vehicle_reg';
    protected $primaryKey = 'v_id';	
}


